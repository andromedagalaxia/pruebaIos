//
//  FotosCollectionViewCell.swift
//  TabBar
//
//  Created by MTWDM on 03/05/21.
//

import UIKit

class FotosCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fotos: UIImageView!
}
