//
//  DetallePlayaCollectionViewCell.swift
//  TabBar
//
//  Created by MTWDM on 30/04/21.
//

import UIKit

class DetallePlayaCollectionViewCell: UICollectionViewCell {
    
}
