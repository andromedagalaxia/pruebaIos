//
//  PlayaCorr.swift
//  TabBar
//
//  Created by MTWDM on 03/05/21.
//

import Foundation

struct PlayaCorr:Decodable {
    var nombre: String
    var foto : String
    var dosis : String
    var sustancia: String!
}
