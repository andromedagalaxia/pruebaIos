//
//  Playas.swift
//  TabBar
//
//  Created by MTWDM on 30/04/21.
//

import Foundation

struct Playas:Decodable {
    var nombre: String
    var foto : String
    var dosis : String
    var sustancia: String!
}
