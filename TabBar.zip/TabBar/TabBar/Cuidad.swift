//
//  Cuidad.swift
//  TabBar
//
//  Created by MTWDM on 03/05/21.
//

import Foundation

struct Cuidad:Decodable {
    var Lugar: String
    var Descripcion : String
}
